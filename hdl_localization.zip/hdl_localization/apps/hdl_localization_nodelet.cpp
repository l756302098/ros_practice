#include <mutex>
#include <memory>
#include <iostream>
#include <boost/circular_buffer.hpp>

#include <ros/ros.h>
#include <pcl_ros/point_cloud.h>
#include <tf_conversions/tf_eigen.h>
#include <tf/transform_broadcaster.h>

#include <nav_msgs/Odometry.h>
#include <sensor_msgs/Imu.h>
#include <sensor_msgs/PointCloud2.h>
#include <geometry_msgs/PoseWithCovarianceStamped.h>


#include <std_msgs/Int16.h>
#include <std_msgs/Bool.h>
#include <std_srvs/SetBool.h>

#include <nodelet/nodelet.h>
#include <pluginlib/class_list_macros.h>

#include <pcl/filters/voxel_grid.h>
#include <pcl/filters/approximate_voxel_grid.h>

#include <pthread.h>
#include <pclomp/ndt_omp.h>
#include <pclomp/gicp_omp.h>
#include <hdl_localization/pose_estimator.hpp>
#include <hdl_localization/CircularBuffer.h>

#include <con_queue.h>
#include <yidamsg/Yida_pose.h>

// Fast pcl and GPU stuff
//#include <fast_pcl/ndt_gpu/NormalDistributionsTransform.h>

struct Pose
{
  double x;
  double y;
  double z;
  double roll;
  double pitch;
  double yaw;
};


namespace hdl_localization {

class HdlLocalizationNodelet : public nodelet::Nodelet {
public:
    using PointT = pcl::PointXYZI;

    HdlLocalizationNodelet() 
    {
	     
    }
    virtual ~HdlLocalizationNodelet() 
    {
      pose_estimator = nullptr;
      pthread_join(tid, NULL);
      test_map_file_.close();
    }

    pthread_t tid;

    void onInit() override 
    {
    	nh = getNodeHandle();
    	mt_nh = getMTNodeHandle();
    	private_nh = getPrivateNodeHandle();

    	initialize_params();

      clear_buffer_ = false;
      first_odom_ = true;
      first_laser_ = true;
      use_sliding_window_ = false;
      global_map_received_flag_ = false;
      laser_process_thread_started_ = false;
      robot_pose_initialized_ = false;
      test_map_ = private_nh.param<bool>("test_map", false);
    	use_imu = private_nh.param<bool>("use_imu", false);
      use_odom = private_nh.param<bool>("use_odom", false);
    	use_ukf = private_nh.param<bool>("use_ukf", false);
      stop_receive_laser_ = private_nh.param<bool>("stop_receive_laser", true);
      laser_hz_ = private_nh.param<int>("laser_frequency", 15);
      process_freq_ = private_nh.param<int>("process_frequency", 30);
      xyz_threshold_ = private_nh.param<double>("xyz_jump_threshold", 1.0);
    	std::string cam_odom_topic = private_nh.param<std::string>("cam_odom_topic", "/odometry");
      std::string point_cloud_topic = private_nh.param<std::string>("point_cloud_topic", "/velodyne_points");
    	std::string imu_data_topic = private_nh.param<std::string>("imu_data_topic", "/imu/data_raw");
    	std::string odom_topic = private_nh.param<std::string>("odom_topic", "/odom_localization");
    	std::string aligned_points_topic = private_nh.param<std::string>("aligned_points_topic", "/aligned_points");
    	sensor_frame_id_topic = private_nh.param<std::string>("sensor_frame_id_topic", "/velodyne");

      // use_gpu_ = false;
      if(test_map_)
      {
        string map_record = private_nh.param<std::string>("test_map_file", "test_map.txt");
        test_map_file_.open(map_record.c_str());
        std::cout << "Testing map......" << std::endl;
      }


    	if(use_imu) 
    	{
    	    NODELET_INFO("enable imu-based prediction");
    	    imu_sub = mt_nh.subscribe(imu_data_topic, 256, &HdlLocalizationNodelet::imu_callback, this);
    	}
      if(use_odom)
      {
          odom_sub = mt_nh.subscribe(cam_odom_topic, 256, &HdlLocalizationNodelet::odom_callback, this);
      }
    	points_sub = mt_nh.subscribe(point_cloud_topic, 1, &HdlLocalizationNodelet::points_callback, this);
    	globalmap_sub = nh.subscribe("/globalmap", 1, &HdlLocalizationNodelet::globalmap_callback, this);
    	initialpose_sub = nh.subscribe("/initialpose", 1, &HdlLocalizationNodelet::initialpose_callback, this);
      buffer_clear_sub = nh.subscribe("/test/clear_laser_buffer", 1, &HdlLocalizationNodelet::buffer_clear_callback, this);
      robot_status_sub = nh.subscribe("/stop_receive_laser", 1, &HdlLocalizationNodelet::laser_status_callback, this);

    	pose_pub = nh.advertise<nav_msgs::Odometry>(odom_topic, 1, false);
    	robot_pose_pub = nh.advertise<yidamsg::Yida_pose>("/robot_pose", 1, false);
    	aligned_pub = nh.advertise<sensor_msgs::PointCloud2>(aligned_points_topic, 1, false);
      laser_buffer_pub = nh.advertise<std_msgs::Int16>("laser_buffer_size", 1, false);
      invalid_jump_pub = nh.advertise<std_msgs::Bool>("invalid_jump", 1, false);
      request_initial_pub = nh.advertise<std_msgs::Bool>("request_robot_pose", 1, false);

      heart_beat_srv_ = nh.advertiseService("/hdl/heartbeat", &HdlLocalizationNodelet::heartbeat, this);

      // use thread to process laser call back
      pthread_create(&tid, NULL, HdlLocalizationNodelet::laserProcess, (void*)this);

    }

private:
    void initialize_params() 
    {
    	// intialize scan matching method
    	double downsample_resolution = private_nh.param<double>("downsample_resolution", 0.1);
    	std::string ndt_neighbor_search_method = private_nh.param<std::string>("ndt_neighbor_search_method", "DIRECT7");

    	double ndt_resolution = private_nh.param<double>("ndt_resolution", 1.0);
    	boost::shared_ptr<pcl::ApproximateVoxelGrid<PointT>> voxelgrid(new pcl::ApproximateVoxelGrid<PointT>());
    //boost::shared_ptr<pcl::VoxelGrid<PointT>> voxelgrid(new pcl::VoxelGrid<PointT>());
    	voxelgrid->setLeafSize(downsample_resolution, downsample_resolution, downsample_resolution);
    	downsample_filter = voxelgrid;

    	pclomp::NormalDistributionsTransform<PointT, PointT>::Ptr ndt(new pclomp::NormalDistributionsTransform<PointT, PointT>());

/*      if(use_gpu_)
      {
        gpu_ndt_.setTransformationEpsilon(0.01);
        gpu_ndt_.setStepSize(0.1);
        gpu_ndt_.setResolution(1.0);
      }*/

    	ndt->setTransformationEpsilon(0.01);
    	ndt->setResolution(ndt_resolution);
            //ndt->setStepSize(0.1);////
    	if(ndt_neighbor_search_method == "DIRECT1") 
    	{
    	    NODELET_INFO("search_method DIRECT1 is selected");
    	    ndt->setNeighborhoodSearchMethod(pclomp::DIRECT1);
    	} 
    	else if(ndt_neighbor_search_method == "DIRECT7") 
    	{
    	    NODELET_INFO("search_method DIRECT7 is selected");
    	    ndt->setNeighborhoodSearchMethod(pclomp::DIRECT7);
    	} 
    	else 
    	{
    	    if(ndt_neighbor_search_method == "KDTREE") 
    	    {
    		    NODELET_INFO("search_method KDTREE is selected");
    	    } 
    	    else 
    	    {
        		NODELET_WARN("invalid search method was given");
        		NODELET_WARN("default method is selected (KDTREE)");
    	    }
    	    ndt->setNeighborhoodSearchMethod(pclomp::KDTREE);
    	}
    	//pclomp::GeneralizedIterativeClosestPoint<PointT, PointT>::Ptr icp(new pclomp::GeneralizedIterativeClosestPoint<PointT, PointT>());
    	registration = ndt;

      private_nh.getParam("init_pos_x", init_x);
      private_nh.getParam("init_pos_y", init_y);
      private_nh.getParam("init_pos_z", init_z);
      private_nh.getParam("init_ori_w", init_q_w);
      private_nh.getParam("init_ori_x", init_q_x);
      private_nh.getParam("init_ori_y", init_q_y);
      private_nh.getParam("init_ori_z", init_q_z);
      private_nh.getParam("odom_threshold", odom_threshold_);

      launch_pos_(0) = init_x;
      launch_pos_(1) = init_y;
      launch_pos_(2) = init_z;
      launch_quat_.w() = init_q_w;
      launch_quat_.x() = init_q_x;
      launch_quat_.y() = init_q_y;
      launch_quat_.z() = init_q_z;

      // initialize pose estimator
      if(private_nh.param<bool>("specify_init_pose", true)) 
      {
        string pose_record = "pose_record.txt";
        NODELET_INFO("initialize pose estimator with specified parameters!!");
        pose_estimator.reset(new hdl_localization::PoseEstimator(registration,
        ros::Time::now(),
        Eigen::Vector3f(init_x, init_y, init_z),
        Eigen::Quaternionf(init_q_w, init_q_x, init_q_y, init_q_z),
        launch_pos_,
        launch_quat_,
        private_nh.param<double>("cool_time_duration", 0.5),
        false,
        private_nh.param<std::string>("pose_record", "pose_record.txt")));
      }
      std::cout << "initiailized pose_estimator...." << std::endl;
      Eigen::Quaternionf quat(init_q_w, init_q_x, init_q_y, init_q_z);
      Eigen::Vector3f euler_angles = quat.toRotationMatrix().eulerAngles(2,1,0);
      current_pose_odom_.x = init_x;
      current_pose_odom_.y = init_y;
      current_pose_odom_.z = init_z;
      current_pose_odom_.roll = euler_angles(2);
      current_pose_odom_.pitch = euler_angles(1);
      current_pose_odom_.yaw = euler_angles(0);



      previous_pose_odom_ = current_pose_odom_;

    }

private:
    /**
     * @brief process pointcloud data in laser buffer and do ndt matching
     * @param clear_buffer_, laser_buffer_
     */
    static void *laserProcess(void* tmp)
    { 
        std::cout << "laser process thread started..." << std::endl;
        sleep(5);
        //std::cout << "after sleep..." << std::endl;
        HdlLocalizationNodelet *hdl = (HdlLocalizationNodelet *)tmp;

        ros::Rate loop_rate(hdl->process_freq_); 
        hdl->laser_process_thread_started_ = true;
        while (ros::ok()) 
        { 
          if(hdl->global_map_received_flag_)
          {
            if(!hdl->robot_pose_initialized_)
            {
              std_msgs::Bool request_pose;
              request_pose.data = true;
              hdl->request_initial_pub.publish(request_pose);
            }

            // if clear buffer set true, clear all the data in buffer
            if(hdl->clear_buffer_)
            {
              std::cout << "clearing buffer..." << std::endl;
              hdl->clear_buffer_ = false;
              hdl->buffer_lock.lock();
              while (!hdl->laser_buffer_.empty()) 
              {
                hdl->laser_buffer_.pop();
              }
              hdl->buffer_lock.unlock();
              if(hdl->use_sliding_window_)
              {
                // clear sliding window
                for(size_t i = 0; i < hdl->window_size_; ++i)
                {
                  hdl->pose_slide_window_[i].setZero();
                }
              }
            }
            //std::cout << "laser process.." << std::endl;

            
            // If we have data in laser buffer, do ndt matching
            if(!hdl->laser_buffer_.empty())
            {
              std_msgs::Int16 buffer_size;
              buffer_size.data = hdl->laser_buffer_.size();
              hdl->laser_buffer_pub.publish(buffer_size);


              hdl->buffer_lock.lock();
              sensor_msgs::PointCloud2ConstPtr points_msg = hdl->laser_buffer_.front();
              hdl->laser_buffer_.pop();
              hdl->buffer_lock.unlock();

              const auto& stamp = points_msg->header.stamp;


              pcl::PointCloud<PointT>::Ptr cloud(new pcl::PointCloud<PointT>());
              pcl::fromROSMsg(*points_msg, *cloud);
              
              if(cloud->empty()) 
              {
                std::cout << "cloud is empty!!" << std::endl;
              }

              // Downsample laser point cloud
              auto filtered = hdl->downsample(cloud);

              pcl::PointCloud<PointT>::Ptr aligned(new pcl::PointCloud<PointT>());
              bool valid_match = true;
              if(!hdl->pose_estimator->get_status())
              {
                  aligned = hdl->pose_estimator->initialize_local(filtered);
              }
              else
              {

                // predict
                if(!hdl->use_imu) 
                {
                  aligned = hdl->pose_estimator->match_global_cloud(filtered, valid_match);
                } 
                else 
                {
                  std::lock_guard<std::mutex> lock(hdl->imu_data_mutex);
                  auto imu_iter = hdl->imu_data.begin();
                  for(imu_iter; imu_iter != hdl->imu_data.end(); imu_iter++) 
                  {
                    //std::cout <<"laser time: " << stamp << ", imu: " << (*imu_iter)->header.stamp << std::endl;
                    if(stamp < (*imu_iter)->header.stamp) 
                    {
                      break;
                    }
                    const auto& acc = (*imu_iter)->linear_acceleration;
                    const auto& gyro = (*imu_iter)->angular_velocity;
                    bool invert_imu = false;
                    double gyro_sign = invert_imu ? -1.0 : 1.0;
                    hdl->pose_estimator->predict((*imu_iter)->header.stamp, Eigen::Vector3f(acc.x, acc.y, acc.z), gyro_sign * Eigen::Vector3f(gyro.x, gyro.y, gyro.z));
                  }
                  hdl->imu_data.erase(hdl->imu_data.begin(), imu_iter);


                  // correct
                  aligned = hdl->pose_estimator->correct(filtered);
                }


                
              }
              
              if(hdl->aligned_pub.getNumSubscribers()) 
              {
                  aligned->header.frame_id = "map";
                  aligned->header.stamp = cloud->header.stamp;
                  hdl->aligned_pub.publish(aligned);
              }

              // check match error
              // use last transformation to update the ukf mean
              if(!valid_match)
              {
                std_msgs::Bool jump_status;
                jump_status.data = true;
                hdl->invalid_jump_pub.publish(jump_status);
              }
              else
              {
                // publish odometry result
                hdl->publish_odometry(ros::Time::now(), hdl->pose_estimator->matrix());

                // get average value of x,y,z from sliding window
                if(hdl->use_sliding_window_)
                {
                  hdl->pose_slide_window_.push(hdl->pose_estimator->pos());
                  Eigen::Vector3f average_pose(Eigen::Vector3f::Zero());
                  for(size_t i=0; i< hdl->window_size_; ++i)
                  {
                    average_pose += hdl->pose_slide_window_[i];
                  }
                  average_pose = average_pose/hdl->window_size_;
                  //std::cout << average_pose(0) << ", " << average_pose(1) << ", " << average_pose(2) << std::endl;
                }

              }
            }

            ros::spinOnce(); 
            loop_rate.sleep(); 
          } 
        }
    }

  // round odometry small number
  double round_small_num(double num)
  {
    if(abs(num)<odom_threshold_)
    {
      return 0.0;
    }
    else
    {
      return num;
    }
  }

  /**
   * @brief calculate odometry travel distance and direction changed from two time stamp.
   * @param current_pose_odom_, previous_pose_odom_, previous_odom_time_
   */
  void odom_calc(ros::Time current_time)
  {
    if(first_odom_)
    {
      previous_odom_time_ = current_time;
      first_odom_ = false;
    }

    double diff_time = (current_time - previous_odom_time_).toSec();

    double diff_odom_roll = curr_odom_.twist.twist.angular.x * diff_time;
    double diff_odom_pitch = curr_odom_.twist.twist.angular.y * diff_time;
    double diff_odom_yaw = curr_odom_.twist.twist.angular.z * diff_time;

    double diff_odom_x = curr_odom_.twist.twist.linear.x * diff_time;
    double diff_odom_y = curr_odom_.twist.twist.linear.y * diff_time;
    double diff_odom_z = curr_odom_.twist.twist.linear.z * diff_time;

    // diff_odom_x = round_small_num(diff_odom_x);
    // diff_odom_y = round_small_num(diff_odom_y);
    // diff_odom_z = round_small_num(diff_odom_z);

    current_pose_odom_.roll  = previous_pose_odom_.roll + diff_odom_roll;
    current_pose_odom_.pitch = previous_pose_odom_.pitch + diff_odom_pitch;
    current_pose_odom_.yaw   = previous_pose_odom_.yaw + diff_odom_yaw;

    current_pose_odom_.x = previous_pose_odom_.x + diff_odom_x;
    current_pose_odom_.y = previous_pose_odom_.y + diff_odom_y;
    current_pose_odom_.z = previous_pose_odom_.z + diff_odom_z;

    previous_pose_odom_ = current_pose_odom_;
    //std::cout << "current pose: " << current_pose_odom_.x << ",  "<< current_pose_odom_.y << ",  " << current_pose_odom_.z << std::endl;

    previous_odom_time_ = current_time;
  }


  /**
   * @brief get robot status.
   * @param stop_receive_laser_
   */
  void laser_status_callback(const std_msgs::BoolConstPtr& msg) 
  {
	  
    stop_receive_laser_ = msg->data;
    buffer_lock.lock();
    while (!laser_buffer_.empty()) 
    {
      laser_buffer_.pop();
    }
    buffer_lock.unlock();
  }


  /**
   * @brief callback for imu data
   * @param imu_msg imu_data
   */
  void imu_callback(const sensor_msgs::ImuConstPtr& imu_msg) 
  {
    if(global_map_received_flag_&&laser_process_thread_started_&&robot_pose_initialized_)
    {
      if(!stop_receive_laser_)
      {
        std::lock_guard<std::mutex> lock(imu_data_mutex);
        imu_data.push_back(imu_msg);
      }
    }
  }

  /**
   * @brief callback for odometry data
   * @param odom_msg curr_odom_
   * @function odom_calc
   */
  void odom_callback(const nav_msgs::OdometryConstPtr& odom_msg) 
  {
    curr_odom_ = *odom_msg;
    odom_calc(odom_msg->header.stamp);
  }


  /**
   * @brief callback for point cloud data
   * @param points_msg
   */
  void points_callback(const sensor_msgs::PointCloud2ConstPtr& points_msg) 
  {
    if(global_map_received_flag_&&laser_process_thread_started_&&robot_pose_initialized_)
    {
      if(!stop_receive_laser_)
      {
        std::lock_guard<std::mutex> estimator_lock(pose_estimator_mutex);

        // laser buffer push data
        buffer_lock.lock();
        laser_buffer_.push(points_msg);
        buffer_lock.unlock();
      }
    }
  }

  /**
   * @brief callback for globalmap input
   * @param points_msg
   */
  void globalmap_callback(const sensor_msgs::PointCloud2ConstPtr& points_msg) 
  {
    NODELET_INFO("globalmap received!");

    pcl::PointCloud<PointT>::Ptr cloud(new pcl::PointCloud<PointT>());
    pcl::fromROSMsg(*points_msg, *cloud);
    globalmap = cloud;
    std::lock_guard<std::mutex> estimator_lock(pose_estimator_mutex);
    ros::Time begin = ros::Time::now();
    registration->setInputTarget(globalmap);
    ros::Time now = ros::Time::now();
    double sec = (now - begin).toSec();
    std::cout << "spend time: " << sec << std::endl;
    global_map_received_flag_ = true;

/*    if(use_gpu_)
    {
      begin = ros::Time::now();
      gpu_mtx_.lock();
      gpu_ndt_.setInputTarget(globalmap);
      gpu_mtx_.unlock();
      now = ros::Time::now();
      sec = (now - begin).toSec();
      std::cout << "GPU spend time: " << sec << std::endl;
    }*/
    std::cout << "global map points: " << globalmap->points.size() << std::endl;
  }

  /**
   * @brief callback for initial pose input ("2D Pose Estimate" on rviz)
   * @param pose_msg
   */
  void initialpose_callback(const geometry_msgs::PoseWithCovarianceStampedConstPtr& pose_msg) {
    NODELET_INFO("initial pose received!!");
    stop_receive_laser_ = true;
    buffer_lock.lock();
    while (!laser_buffer_.empty()) 
    {
      laser_buffer_.pop();
    }
    buffer_lock.unlock();

    std::lock_guard<std::mutex> lock(pose_estimator_mutex);
    const auto& p = pose_msg->pose.pose.position;
    const auto& q = pose_msg->pose.pose.orientation;
    Eigen::Vector3f pos(p.x, p.y, init_z);
    Eigen::Quaternionf quat(q.w, q.x, q.y, q.z);
    cout << "initial position....." << endl;
    cout << "x,y,z: " << p.x << " " << p.y << " " << init_z << endl;
    cout << "w,x,y,z: " << q.w << " " << q.x << " " << q.y << " " << q.z << endl;
    pose_estimator.reset(
          new hdl_localization::PoseEstimator(
            registration,
            ros::Time::now(),
	          pos,
            quat,
            launch_pos_,
            launch_quat_,
            private_nh.param<double>("cool_time_duration", 0.5),
      	    false,
            private_nh.param<std::string>("pose_record", "pose_record.txt")
	));
    if(use_sliding_window_)
    {
      pose_slide_window_.Reset(window_size_ + 1);
    }

    stop_receive_laser_ = false;
    robot_pose_initialized_ = true;
  }

  bool heartbeat(std_srvs::SetBool::Request &req,
                 std_srvs::SetBool::Response &res)
  {
    cout << "alive ..." << endl;
    res.success = true;
    return true;
  }
  

  void buffer_clear_callback(const std_msgs::BoolConstPtr& data) 
  {
    clear_buffer_ = data->data;
  }
  
  /**
   * @brief downsampling
   * @param cloud   input cloud
   * @return downsampled cloud
   */
  pcl::PointCloud<PointT>::ConstPtr downsample(const pcl::PointCloud<PointT>::ConstPtr& cloud) const {
    if(!downsample_filter) {
      return cloud;
    }

    pcl::PointCloud<PointT>::Ptr filtered(new pcl::PointCloud<PointT>());
    downsample_filter->setInputCloud(cloud);
    downsample_filter->filter(*filtered);
    filtered->header = cloud->header;

    return filtered;
  }

  /**
   * @brief publish odometry
   * @param stamp  timestamp
   * @param pose   odometry pose to be published
   */
  void publish_odometry(const ros::Time& stamp, const Eigen::Matrix4f& pose) {
    // broadcast the transform over tf
    geometry_msgs::TransformStamped odom_trans = matrix2transform(stamp, pose, "map", sensor_frame_id_topic);
    pose_broadcaster.sendTransform(odom_trans);

    // publish the transform
    nav_msgs::Odometry odom;
    odom.header.stamp = stamp;
    odom.header.frame_id = "map";

    odom.pose.pose.position.x = pose(0, 3);
    odom.pose.pose.position.y = pose(1, 3);
    odom.pose.pose.position.z = pose(2, 3);
    odom.pose.pose.orientation = odom_trans.transform.rotation;

    double match_score = pose_estimator->score();
    odom.pose.covariance[0] = match_score;
//     odom.child_frame_id = "velodyne";
//     odom.twist.twist.linear.x = 0.0;
//     odom.twist.twist.linear.y = 0.0;
//     odom.twist.twist.angular.z = 0.0;
    if(test_map_)
    {
      test_map_file_ << odom.pose.pose.position.x << " " << odom.pose.pose.position.y << " " << odom.pose.pose.position.z << " " << odom.pose.pose.orientation.w << " " << odom.pose.pose.orientation.x << " " << odom.pose.pose.orientation.y << " " << odom.pose.pose.orientation.z << " " << match_score << std::endl;
    }

    pose_pub.publish(odom);
    
    // publish yida pose
    Eigen::Quaternionf quaternion = Eigen::Quaternionf(odom.pose.pose.orientation.w, odom.pose.pose.orientation.x, odom.pose.pose.orientation.y, odom.pose.pose.orientation.z);
    Eigen::Matrix3f M;
    M = quaternion.toRotationMatrix();
    Eigen::Vector3f euler_angles = M.eulerAngles(0,1,2);
    yidamsg::Yida_pose robot_point;
    int i = 0;
    int j = 1;
    int k = 2;
    float q_anglex = 0.0;
    float q_angley = 0.0;
    float q_anglez = 0.0;
    float value_if = 8.881784197001252e-16;
    float cy = sqrt(M(i, i)*M(i, i) + M(j, i)*M(j, i));

    if(cy > value_if)
    {
      q_anglex = atan2f( M(k, j),  M(k, k));
      q_angley = atan2f(-M(k, i),  cy);
      q_anglez = atan2f( M(j, i),  M(i, i));
    }
    else
    {
      q_anglex = atan2(-M(j, k),  M(j, j));
      q_angley = atan2(-M(k, i),  cy);
      q_anglez = 0.0;
    }

    robot_point.x = pose(0, 3);
    robot_point.y = pose(2, 3);
    robot_point.z = pose(1, 3);
    robot_point.anglex = q_anglex;
    robot_point.angley = q_angley;
    robot_point.anglez = q_anglez;

    robot_pose_pub.publish(robot_point);
  }

  /**
   * @brief convert a Eigen::Matrix to TransformedStamped
   * @param stamp           timestamp
   * @param pose            pose matrix
   * @param frame_id        frame_id
   * @param child_frame_id  child_frame_id
   * @return transform
   */
  geometry_msgs::TransformStamped matrix2transform(const ros::Time& stamp, const Eigen::Matrix4f& pose, const std::string& frame_id, const std::string& child_frame_id) {
    Eigen::Quaternionf quat(pose.block<3, 3>(0, 0));
    quat.normalize();
    geometry_msgs::Quaternion odom_quat;
    odom_quat.w = quat.w();
    odom_quat.x = quat.x();
    odom_quat.y = quat.y();
    odom_quat.z = quat.z();

    geometry_msgs::TransformStamped odom_trans;
    odom_trans.header.stamp = stamp;
    odom_trans.header.frame_id = frame_id;
    odom_trans.child_frame_id = child_frame_id;

    odom_trans.transform.translation.x = pose(0, 3);
    odom_trans.transform.translation.y = pose(1, 3);
    odom_trans.transform.translation.z = pose(2, 3);
    odom_trans.transform.rotation = odom_quat;

    return odom_trans;
  }

private:
  // ROS stuff
  ros::NodeHandle nh;
  ros::NodeHandle mt_nh;
  ros::NodeHandle private_nh;

  ros::ServiceServer heart_beat_srv_;

  ros::Subscriber imu_sub, odom_sub, points_sub, globalmap_sub, initialpose_sub, buffer_clear_sub, robot_status_sub;

  ros::Publisher pose_pub, robot_pose_pub, aligned_pub, laser_buffer_pub, invalid_jump_pub, request_initial_pub;

  // global parameters
  size_t window_size_=10;
  int laser_hz_;                 // Laser callback normal frequency
  int process_freq_;             // Process frequency for point cloud message
  double odom_threshold_;        // Valid odometry value threshold
  double xyz_threshold_;          // Jumping threshold in x, y, z direction
  float init_x, init_y, init_z, init_q_w, init_q_x, init_q_y, init_q_z;   // Initial x, z, y, qw, qx, qy, qz
  bool test_map_;
  bool use_gpu_;                  // Use gpu ndt
  bool use_imu;                   // Use imu message
  bool use_odom;                  // Use odometry message
  bool use_ukf;                   // Use ukf
  bool use_sliding_window_;       // Use sliding window
  bool first_odom_;               // First odometry data flag
  bool first_laser_;              // First laser data flag
  bool clear_buffer_;             // Clear current laser buffer
  bool stop_receive_laser_;               // If robot stop, stop receiving laser pointcloud data
  bool global_map_received_flag_;
  bool laser_process_thread_started_;
  bool robot_pose_initialized_;
  tf::TransformBroadcaster pose_broadcaster;

  nav_msgs::Odometry curr_odom_;

  // imu input buffer
  std::mutex imu_data_mutex;
  std::vector<sensor_msgs::ImuConstPtr> imu_data;

  // pose estimator ptr
  std::mutex pose_estimator_mutex;
  std::unique_ptr<hdl_localization::PoseEstimator> pose_estimator;

  // laser queue
  std::mutex buffer_lock;
  concurrent_queue<sensor_msgs::PointCloud2ConstPtr> laser_buffer_;

  // globalmap and registration method
  pcl::PointCloud<PointT>::Ptr globalmap;
  pcl::Registration<PointT, PointT>::Ptr registration;
  
  
  //std::mutex gpu_mtx_;
  //gpu::GNormalDistributionsTransform gpu_ndt_;
  // pose estimator

  // Use for testing map
  ofstream test_map_file_;

  std::string sensor_frame_id_topic;                        // Laser sensor frame id
  pcl::Filter<PointT>::Ptr downsample_filter;       // PCL downsample filter

  Pose current_pose_odom_, previous_pose_odom_;             // Previous odometry pose

  Eigen::Vector3f launch_pos_;
  Eigen::Quaternionf launch_quat_;
  ros::Time previous_odom_time_;                            // Last odometry data time stamp

  CircularBuffer<Eigen::Vector3f> pose_slide_window_{window_size_ + 1};
};

}


PLUGINLIB_EXPORT_CLASS(hdl_localization::HdlLocalizationNodelet, nodelet::Nodelet)
