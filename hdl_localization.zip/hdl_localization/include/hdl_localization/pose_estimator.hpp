#ifndef POSE_ESTIMATOR_HPP
#define POSE_ESTIMATOR_HPP

#include <memory>
#include <iostream>
#include <fstream>

#include <ros/ros.h>
#include <pcl/point_types.h>
#include <pcl/point_cloud.h>

#include <pclomp/ndt_omp.h>
#include <pcl/filters/voxel_grid.h>

#include <hdl_localization/pose_system.hpp>
#include <kkl/alg/unscented_kalman_filter.hpp>

#include <Eigen/Core>
#include <Eigen/Dense>
#include <Eigen/Geometry>

namespace hdl_localization
{
using namespace std;
#define BIG_NUM 999999
/**
 * @brief scan matching-based pose estimator
 */
class PoseEstimator
{
public:
  using PointT = pcl::PointXYZI;

  Eigen::Vector3f previous_pos;
  Eigen::Quaternionf previous_qua;

  /**
   * @brief constructor
   * @param registration        registration method
   * @param stamp               timestamp
   * @param pos                 initial position
   * @param quat                initial orientation
   * @param cool_time_duration  during "cool time", prediction is not performed
   */
  PoseEstimator(pcl::Registration<PointT, PointT>::Ptr &registration, const ros::Time &stamp, const Eigen::Vector3f &pos, const Eigen::Quaternionf &quat,  const Eigen::Vector3f& launch_pos, const Eigen::Quaternionf& launch_quat, double cool_time_duration = 1.0, bool initialized = false, string pose_record = "pose_record.txt")
      : init_stamp(stamp),
        registration(registration),
        cool_time_duration(cool_time_duration),
        pose_record(pose_record),
        initialized(initialized)
  {
    previous_pos = Eigen::Vector3f::Zero();
    previous_qua.w() = 1.0;
    previous_qua.x() = 0.0;
    previous_qua.y() = 0.0;
    previous_qua.z() = 0.0;

    match_score_ = 0.0;
    process_noise = Eigen::MatrixXf::Identity(16, 16);
    process_noise.middleRows(0, 3) *= 1.0;
    process_noise.middleRows(3, 3) *= 1.0;
    process_noise.middleRows(6, 4) *= 0.5;
    process_noise.middleRows(10, 3) *= 1e-6;
    process_noise.middleRows(13, 3) *= 1e-6;

    Eigen::MatrixXf measurement_noise = Eigen::MatrixXf::Identity(7, 7);
    measurement_noise.middleRows(0, 3) *= 0.01;
    measurement_noise.middleRows(3, 4) *= 0.001;

    Eigen::VectorXf mean(16);
    mean.middleRows(0, 3) = pos;
    mean.middleRows(3, 3).setZero();
    mean.middleRows(6, 4) = Eigen::Vector4f(quat.w(), quat.x(), quat.y(), quat.z());
    mean.middleRows(10, 3).setZero();
    mean.middleRows(13, 3).setZero();

    init_pos_ = launch_pos;
    init_quat_ = launch_quat;

    last_robot_xyz_ = pos;
    last_robot_quat_ = quat;

    Eigen::MatrixXf cov = Eigen::MatrixXf::Identity(16, 16) * 0.01;

    PoseSystem system;
    ukf.reset(new kkl::alg::UnscentedKalmanFilterX<float, PoseSystem>(system, 16, 6, 7, process_noise, measurement_noise, mean, cov));
  }

  ~PoseEstimator()
  {
    ofstream map_points;
    map_points.open(pose_record.c_str());
    map_points << previous_pos(0) << " " << previous_pos(1) << " " << previous_pos(2) << " " << previous_qua.w() << " " << previous_qua.x() << " " << previous_qua.y() << " " << previous_qua.z() << std::endl;
    map_points.close();
    std::cout << "record success " << std::endl;
  }

  /**
   * @brief predict
   * @param stamp    timestamp
   * @param acc      acceleration
   * @param gyro     angular velocity
   */
  void predict(const ros::Time &stamp, const Eigen::Vector3f &acc, const Eigen::Vector3f &gyro)
  {
    if ((stamp - init_stamp).toSec() < cool_time_duration || prev_stamp.is_zero() || prev_stamp == stamp)
    {
      prev_stamp = stamp;
      return;
    }

    double dt = (stamp - prev_stamp).toSec();
    prev_stamp = stamp;

    ukf->setProcessNoiseCov(process_noise * dt);
    ukf->system.dt = dt;

    Eigen::VectorXf control(6);
    control.head<3>() = acc;
    control.tail<3>() = gyro;
    //     cout << "mean of ukf before predict is: \n" << ukf->mean << endl;
    //     cout << "control input of ukf before predict is: \n" << control << endl;
    ukf->predict(control);
    //     cout << "mean of ukf after predict is: \n" << ukf->mean << endl;
  }

  /**
   * @brief correct
   * @param cloud   input cloud
   * @return cloud aligned to the globalmap
   */
  pcl::PointCloud<PointT>::Ptr correct(const pcl::PointCloud<PointT>::ConstPtr &cloud)
  {
    Eigen::Matrix4f init_guess = Eigen::Matrix4f::Identity();
    init_guess.block<3, 3>(0, 0) = quat().toRotationMatrix();
    init_guess.block<3, 1>(0, 3) = pos();

    pcl::PointCloud<PointT>::Ptr aligned(new pcl::PointCloud<PointT>());
    registration->setInputSource(cloud);
    registration->align(*aligned, init_guess);

    Eigen::Matrix4f trans = registration->getFinalTransformation();
    Eigen::Vector3f p = trans.block<3, 1>(0, 3);
    Eigen::Quaternionf q(trans.block<3, 3>(0, 0));

    if (quat().vec().dot(q.vec()) < 0.0f)
    {
      q.coeffs() *= -1.0f;
    }

    Eigen::VectorXf observation(7);
    observation.middleRows(0, 3) = p;
    observation.middleRows(3, 4) = Eigen::Vector4f(q.w(), q.x(), q.y(), q.z());

    ukf->correct(observation);
    return aligned;
  }

  /**
   * @brief Ndt matching function -> use input cloud and align with global cloud
   * @param init_guess, cloud, registration, ukf->mean
   * @return aligned
   */
  pcl::PointCloud<PointT>::Ptr match_global_cloud(const pcl::PointCloud<PointT>::ConstPtr &cloud, bool valid)
  {
    Eigen::Matrix4f init_guess = Eigen::Matrix4f::Identity();
    init_guess.block<3, 3>(0, 0) = quat().toRotationMatrix();
    init_guess.block<3, 1>(0, 3) = pos();

    pcl::PointCloud<PointT>::Ptr aligned(new pcl::PointCloud<PointT>());
    registration->setInputSource(cloud);
    registration->align(*aligned, init_guess);
    match_score_ = registration->getFitnessScore();

    Eigen::Matrix4f trans = registration->getFinalTransformation();
    Eigen::Vector3f p = trans.block<3, 1>(0, 3);
    Eigen::Quaternionf q(trans.block<3, 3>(0, 0));

    if (quat().vec().dot(q.vec()) < 0.0f)
    {
      q.coeffs() *= -1.0f;
    }

    if(check_invalid_jump(p,q,last_robot_xyz_, last_robot_quat_))
    {
      p = last_robot_xyz_;
      q = last_robot_quat_;
      valid = false;
    }

    ukf->mean.middleRows(0, 3) = p;
    ukf->mean.middleRows(6, 4) = Eigen::Vector4f(q.w(), q.x(), q.y(), q.z());


    previous_pos = p;
    previous_qua = q;

    // update last data.
    last_robot_xyz_ = p;
    last_robot_quat_ = q;

    return aligned;
  }

  bool check_invalid_jump(Eigen::Vector3f curr_pos, Eigen::Quaternionf curr_quat, Eigen::Vector3f last_robot_xyz_, Eigen::Quaternionf last_robot_quat_)
  {
    // check match error
    // use last transformation to update the ukf mean
    if(abs(curr_pos(0) - last_robot_xyz_(0)) > 1.0 ||  abs(curr_pos(1) - last_robot_xyz_(1)) > 1.0 )// only consider x,y || abs(curr_pos(2) - last_robot_xyz_(2)) > xyz_threshold_)
    {
      std::cout << "Error: Jumping in result!" << abs(curr_pos(0) - last_robot_xyz_(0)) << ", " << abs(curr_pos(1) - last_robot_xyz_(1)) << ", " << abs(curr_pos(2) - last_robot_xyz_(2)) << std::endl;
      return true;
    }
    else
    {
      return false;
    }

  }
  /**
   * @brief Pose_estimator update ukf mean value
   * @param ukf->mean
   */
  void update_ukf_state(Eigen::Vector3f p, Eigen::Quaternionf q)
  {
    if (quat().vec().dot(q.vec()) < 0.0f)
    {
      q.coeffs() *= -1.0f;
    }
    ukf->mean.middleRows(0, 3) = p;
    ukf->mean.middleRows(6, 4) = Eigen::Vector4f(q.w(), q.x(), q.y(), q.z());
  }

  /**
   * @brief Initialize pose function
   * @param cloud, pose_record, map_points, ukf->mean, score
   * @return aligned
   */
  // 
  pcl::PointCloud<PointT>::Ptr initialize_local(const pcl::PointCloud<PointT>::ConstPtr &cloud)
  {
    Eigen::Matrix4f init_guess = Eigen::Matrix4f::Identity();
    Eigen::Matrix4f trans = Eigen::Matrix4f::Identity();
    pcl::PointCloud<PointT>::Ptr aligned(new pcl::PointCloud<PointT>());

    init_guess.block<3, 3>(0, 0) = quat().toRotationMatrix();
    init_guess.block<3, 1>(0, 3) = pos();

    registration->setInputSource(cloud);
    registration->align(*aligned, init_guess);
    double score = registration->getFitnessScore();
    trans = registration->getFinalTransformation();
    std::cout << "fitness score of origin point is: " << score << std::endl;
    

    pcl::PointCloud<PointT>::Ptr aligned2(new pcl::PointCloud<PointT>());
    init_guess.block<3, 3>(0, 0) = init_quat_.toRotationMatrix();
    init_guess.block<3, 1>(0, 3) = init_pos_;
    registration->align(*aligned2, init_guess);
    std::cout << "fitness score 2 of origin point is: " << registration->getFitnessScore() << std::endl;
    if (registration->getFitnessScore() < score)
    {
      aligned = aligned2;
      score = registration->getFitnessScore();
      trans = registration->getFinalTransformation();
    }
    cout << "launch initial pose fitness score of last position is: " << registration->getFitnessScore() << endl;

    if (score < 2)
    {
      Eigen::Vector3f p = trans.block<3, 1>(0, 3);
      Eigen::Quaternionf q(trans.block<3, 3>(0, 0));

      if (quat().vec().dot(q.vec()) < 0.0f)
      {
        q.coeffs() *= -1.0f;
      }
      ukf->mean.middleRows(0, 3) = p;
      ukf->mean.middleRows(6, 4) = Eigen::Vector4f(q.w(), q.x(), q.y(), q.z());
      initialized = true;
      previous_pos = p;
      previous_qua = q;
      last_robot_xyz_ = p;
      last_robot_quat_ = q;
      std::cout << "pose estimator initialized " << std::endl;
      std::cout << "initial pose estimate is: " << p.transpose() << std::endl;
      return aligned;
    }
    else
    {
      std::cout << "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!" << std::endl;
      std::cout << "can not initialize the localization system!" << std::endl;
      std::cout << "please move the robot to the origin point!" << std::endl;
      std::cout << "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!" << std::endl;
    }
  }

  // check if number is valid
  bool check_valid_num(double num)
  {
    //bool result;
    return (abs(num)>BIG_NUM) ?0:1;
  }

  /* getters */
  Eigen::Vector3f pos() const
  {
    return Eigen::Vector3f(ukf->mean[0], ukf->mean[1], ukf->mean[2]);
  }

  Eigen::Vector3f vel() const
  {
    return Eigen::Vector3f(ukf->mean[3], ukf->mean[4], ukf->mean[5]);
  }

  Eigen::Quaternionf quat() const
  {
    return Eigen::Quaternionf(ukf->mean[6], ukf->mean[7], ukf->mean[8], ukf->mean[9]).normalized();
  }

  double score() const
  {
    return match_score_;
  }

  Eigen::Matrix4f matrix() const
  {
    Eigen::Matrix4f m = Eigen::Matrix4f::Identity();
    m.block<3, 3>(0, 0) = quat().toRotationMatrix();
    m.block<3, 1>(0, 3) = pos();
    return m;
  }
  bool get_status() const
  {
    return initialized;
  }

private:
  ros::Time init_stamp;      // when the estimator was initialized
  ros::Time prev_stamp;      // when the estimator was updated last time
  double cool_time_duration; //
  double match_score_;
  bool initialized;
  string pose_record;
  Eigen::MatrixXf process_noise;
  std::unique_ptr<kkl::alg::UnscentedKalmanFilterX<float, PoseSystem>> ukf;
  pcl::Registration<PointT, PointT>::Ptr registration;
  Eigen::Vector3f init_pos_;
  Eigen::Quaternionf init_quat_;

  Eigen::Vector3f last_robot_xyz_;                          // Last valid robot x, y, z
  Eigen::Quaternionf last_robot_quat_;                      // Last valid robot quaternion
};

} // namespace hdl_localization

#endif // POSE_ESTIMATOR_HPP
